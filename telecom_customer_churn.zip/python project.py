import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset (correct file path formatting)
df = pd.read_csv(r"C:\Users\sangu\Desktop\pyall\telecom_customer_churn.csv")

# Preview columns to confirm names
print("Columns:", df.columns.tolist())

# Preprocessing: Create binary churn column
if 'Customer Status' in df.columns:
    df['Churn'] = df['Customer Status'].apply(lambda x: 1 if x == 'Churned' else 0)
else:
    raise KeyError("Column 'Customer Status' not found.")

# Convert 'Total Charges' to numeric (if needed)
if 'Total Charges' in df.columns:
    df['Total Charges'] = pd.to_numeric(df['Total Charges'], errors='coerce')

# 1. Overall Churn Rate
churn_rate = df['Churn'].mean()
plt.figure(figsize=(5, 4))
sns.countplot(data=df, x='Churn')
plt.title(f'Overall Churn Rate: {churn_rate:.2%}')
plt.xticks([0, 1], ['Stayed', 'Churned'])
plt.show()

# 2. Churn by Demographics
demographics = ['Gender', 'Married', 'Number of Dependents']
for col in demographics:
    if col in df.columns:
        plt.figure(figsize=(6, 4))
        sns.barplot(data=df, x=col, y='Churn')
        plt.title(f'Churn Rate by {col}')
        plt.show()

# 3. Tenure vs Churn
if 'Tenure in Months' in df.columns:
    plt.figure(figsize=(8, 4))
    sns.histplot(data=df, x='Tenure in Months', hue='Churn', bins=30, kde=True, multiple='stack')
    plt.title('Tenure Distribution by Churn Status')
    plt.show()

# 4. Churn Across Services
services = ['Phone Service', 'Multiple Lines', 'Internet Service', 'Online Security',
            'Online Backup', 'Device Protection Plan', 'Streaming TV', 'Streaming Movies']
for service in services:
    if service in df.columns:
        plt.figure(figsize=(6, 4))
        sns.barplot(data=df, x=service, y='Churn')
        plt.title(f'Churn by {service}')
        plt.xticks(rotation=45)
        plt.show()

# 5. Monthly Charges: Churned vs Non-Churned
monthly_charge_col = 'Monthly Charges' if 'Monthly Charges' in df.columns else 'Monthly Charge'
if monthly_charge_col in df.columns:
    plt.figure(figsize=(6, 4))
    sns.boxplot(data=df, x='Churn', y=monthly_charge_col)
    plt.title('Monthly Charges: Churned vs Non-Churned')
    plt.xticks([0, 1], ['Stayed', 'Churned'])
    plt.show()

# 6. Contract Type Impact
if 'Contract' in df.columns:
    plt.figure(figsize=(6, 4))
    sns.barplot(data=df, x='Contract', y='Churn')
    plt.title('Churn Rate by Contract Type')
    plt.xticks(rotation=45)
    plt.show()

# 7. Payment Methods
if 'Payment Method' in df.columns:
    plt.figure(figsize=(8, 4))
    sns.barplot(data=df, x='Payment Method', y='Churn')
    plt.title('Churn by Payment Method')
    plt.xticks(rotation=45)
    plt.show()

# 8. Total Charges vs Tenure with Churn
if 'Tenure in Months' in df.columns and 'Total Charges' in df.columns:
    plt.figure(figsize=(8, 5))
    sns.scatterplot(data=df, x='Tenure in Months', y='Total Charges', hue='Churn', alpha=0.6)
    plt.title('Total Charges vs Tenure')
    plt.show()

# 9. Correlation Heatmap
num_cols = df.select_dtypes(include=['float64', 'int64']).copy()
corr = num_cols.corr()
plt.figure(figsize=(12, 8))
sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.show()

# 10. Missing & Anomalous Data
plt.figure(figsize=(12, 6))
sns.heatmap(df.isnull(), cbar=False, yticklabels=False, cmap='viridis')
plt.title('Missing Data Visualization')
plt.show()

# Print missing values summary
print("Missing values per column:\n", df.isnull().sum())
